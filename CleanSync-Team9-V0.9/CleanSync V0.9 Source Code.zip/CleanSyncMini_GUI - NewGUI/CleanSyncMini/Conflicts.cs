﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CleanSyncMini;

namespace DirectoryInformation
{
    public class Conflicts
    {

        public enum FolderFileType
        {
            FolderConflict,
            FileConflict,
            FolderVSFileConflict,
            FileVSFolderConflict,
            FolderVSSubFolderConflict,
            SubFolderVSFolderConflict
        }

        public enum UserChoice
        {
            KeepPCUpdates,
            KeepUSBUpdates,
            Untouched
        }

        public enum ConflictType
        {
            New,
            Modified,
            Deleted
        }
        public enum ConflictComplexity
        {
            OneToOne,
            OneToMany
        }
       

        public Conflicts(FolderFileType type,FolderMeta currentPCFolder, FolderMeta USBFolder, ConflictType PCFolderFileType, ConflictType USBFolderFileType, ConflictComplexity complexity)
        {
            this.CurrentPCFolder = currentPCFolder;
            this.USBFolder  = USBFolder;
            this.FolderOrFileConflictType = type;
            this.PCFolderFileType = PCFolderFileType;
            this.USBFolderFileType = USBFolderFileType;
            this.Complexity = complexity;
            InitializeNameAndImage();
            
        }

        private void InitializeNameAndImage()
        {
            this.Name = GetName();
            this.setIconImage();
            setConflictionTypImageSource();
        }

        private void setConflictionTypImageSource()
        {
            switch (this.PCFolderFileType)
            {
                case ConflictType.New:
                    this.PCConflictTypeImage = "Pic/Create.png";
                    break;
                case ConflictType.Deleted:
                    this.PCConflictTypeImage = "Pic/Delete.png";
                    break;
                case ConflictType.Modified:
                    this.PCConflictTypeImage = "Pic/Modify.png";
                    break;
            }

            switch (this.USBFolderFileType)
            {
                case ConflictType.New:
                    this.USBConflictTypeImage = "Pic/Create.png";
                    break;
                case ConflictType.Deleted:
                    this.USBConflictTypeImage = "Pic/Delete.png";
                    break;
                case ConflictType.Modified:
                    this.USBConflictTypeImage = "Pic/Modify.png";
                    break;
            }
        }
        public Conflicts(FolderFileType type,FolderMeta currentPCFolder, FileMeta USBFile, ConflictType PCFolderFileType, ConflictType USBFolderFileType, ConflictComplexity complexity)
        {
            this.CurrentPCFolder = currentPCFolder;
            this.USBFile = USBFile;
            this.FolderOrFileConflictType = type;
            this.PCFolderFileType = PCFolderFileType;
            this.USBFolderFileType = USBFolderFileType;
            this.Complexity = complexity;
            InitializeNameAndImage();
        }
        public Conflicts(FolderFileType type, FileMeta currentPCFile, FolderMeta USBFolder, ConflictType PCFolderFileType, ConflictType USBFolderFileType, ConflictComplexity complexity)
        {
            this.CurrentPCFile = currentPCFile;
            this.USBFolder = USBFolder;
            this.FolderOrFileConflictType =type;
            this.PCFolderFileType = PCFolderFileType;
            this.USBFolderFileType = USBFolderFileType;
            this.Complexity = complexity;
            InitializeNameAndImage();
        }
        public Conflicts(FolderFileType type,FileMeta currentPCFile, FileMeta USBFile, ConflictType PCFolderFileType, ConflictType USBFolderFileType, ConflictComplexity complexity)
        {
            this.CurrentPCFile = currentPCFile;
            this.USBFile = USBFile;
            this.FolderOrFileConflictType = type;
            this.PCFolderFileType = PCFolderFileType;
            this.USBFolderFileType = USBFolderFileType;
            this.Complexity = complexity;
            InitializeNameAndImage();
        }
        public FolderMeta CurrentPCFolder
        {
            get;
            set;
        }
       
        public FolderMeta USBFolder
        {
            get;
            set;
        }
        public FileMeta CurrentPCFile
        {
            get;
            set;
        }
        public FileMeta USBFile
        {
            get;
            set;
        }
        public FolderFileType FolderOrFileConflictType
        {
            get;
            set;
        }

        public ConflictType PCFolderFileType
        {
            get;
            set;
        }
        public ConflictType USBFolderFileType
        {
            get;
            set;
        }

        public ConflictComplexity Complexity
        {
            set;
            get;
        }

        public string Name
        {
            set;
            get;
        }

        public bool USBSelected
        {
            get;
            set;
        }

        public bool PCSelected
        {
            get;
            set;
        }
        public System.Windows.Media.ImageSource itemIconImage
        {
            get;
            set;
        }
        public string PCConflictTypeImage
        {
            get;
            set;
        }
        public string USBConflictTypeImage
        {
            get;
            set;
        }
        public override string ToString()
        {
            string result ="";
            if(this.FolderOrFileConflictType == Conflicts.FolderFileType.FolderConflict)
            { 
                result  += "[FolderConflict]";
                result  +=  "PCFolder: " +this.CurrentPCFolder.AbsolutePath + "("+ this.PCFolderFileType + ")" + " conflicts with  USBFolder" + this.USBFolder.AbsolutePath +"("+ this.USBFolderFileType +")";
            }
            else
            {
                result  += "[FileConflict]";
                result  +=  "PCFile: " +this.CurrentPCFile.AbsolutePath + "("+ this.PCFolderFileType + ")" + " conflicts with  USBFile" + this.USBFile.AbsolutePath +"("+ this.USBFolderFileType +")";
            }


            return result;
        }

        internal string GetName()
        {
            string result = null;
            switch (this.FolderOrFileConflictType)
            {
                case Conflicts.FolderFileType.FileConflict:
                    result = this.CurrentPCFile.Path + this.CurrentPCFile.Name;
                    break;
                case Conflicts.FolderFileType.FolderConflict:
                    result = this.CurrentPCFolder.Path + this.CurrentPCFolder.Name;
                    break;
                case Conflicts.FolderFileType.FolderVSFileConflict:
                    result = this.USBFile.Path + this.USBFile.Name;
                    break;
                case Conflicts.FolderFileType.FileVSFolderConflict:
                    result = this.CurrentPCFile.Path + this.CurrentPCFile.Name;
                    break;
                case Conflicts.FolderFileType.FolderVSSubFolderConflict:
                    result = this.USBFolder.Path + this.USBFolder.Name;
                    break;
                case Conflicts.FolderFileType.SubFolderVSFolderConflict:
                    result = this.CurrentPCFolder.Path + this.CurrentPCFolder.Name;
                    break;

            }
            return result;
        }

        public Conflicts.UserChoice getUserChoice()
        {
            if (USBSelected) return Conflicts.UserChoice.KeepUSBUpdates;
            else if (PCSelected) return Conflicts.UserChoice.KeepPCUpdates;
            else return Conflicts.UserChoice.Untouched;
        }

        private void setIconImage()
        {
            if (this.FolderOrFileConflictType.Equals(Conflicts.FolderFileType.FolderConflict))
            {
                this.itemIconImage = IconExtractor.GetFolderIconImage();
            }
            else
            {
                this.itemIconImage = IconExtractor.GetFileIconImage(this.GetName());
            }
        }
    }
}
